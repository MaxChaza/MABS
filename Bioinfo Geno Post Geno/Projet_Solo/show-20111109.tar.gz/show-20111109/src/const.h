#define LOG


#define LGSTRING 256
#define LGBLOC 1000
#define LGLINE 5000
#define LGMAX_WORD 200
#define PRECISION 0.001

