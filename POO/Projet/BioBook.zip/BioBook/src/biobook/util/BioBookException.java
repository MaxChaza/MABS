package biobook.util;

public class BioBookException  extends Exception{
	
		private static final long serialVersionUID = 1L;

		public BioBookException(){
			super();
		}
		
		public BioBookException(String msg){
			super(msg);
		}

	}

