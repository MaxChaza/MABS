/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.view;

/**
 *
 * @author Maxime
 */
class CreerMaterielView {

    CreerMaterielView(MainFrame aThis) {
        throw new UnsupportedOperationException("Not yet implemented");
    }
    
}
