
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `biobook`
--

-- --------------------------------------------------------

--
-- Structure de la table `chercheur`
--

CREATE TABLE IF NOT EXISTS `chercheur` (
  `login` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `name` varchar(200) NOT NULL,
  `firstName` varchar(200) NOT NULL,
  `mail` varchar(400) NOT NULL,
  PRIMARY KEY (`login`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `chercheur_experience`
--

CREATE TABLE IF NOT EXISTS `chercheur_experience` (
  `login` varchar(200) NOT NULL,
  `labelExperience` varchar(200) NOT NULL,
  PRIMARY KEY (`login`,`labelExperience`),
  KEY `fk_cher` (`labelExperience`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `document`
--

CREATE TABLE IF NOT EXISTS `document` (
  `labelDocument` varchar(200) NOT NULL,
  `labelExperience` varchar(200) NOT NULL,
  `valeur` varchar(3000) NOT NULL,
  PRIMARY KEY (`labelDocument`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `experience`
--

CREATE TABLE IF NOT EXISTS `experience` (
  `labelExperience` varchar(200) NOT NULL,
  `problem` varchar(2000) NOT NULL,
  `context` varchar(2000) NOT NULL,
  `stateOfArt` varchar(2000) NOT NULL,
  `assumption` varchar(200) NOT NULL,
  `createur` varchar(200) NOT NULL,
  PRIMARY KEY (`labelExperience`),
  KEY `fk_exp_crea` (`createur`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `materiel`
--

CREATE TABLE IF NOT EXISTS `materiel` (
  `labelMateriel` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Contenu de la table `materiel`
--

INSERT INTO `materiel` (`labelMateriel`) VALUES
('Pipette'),
('truelle');

-- --------------------------------------------------------

--
-- Structure de la table `materiel_experience`
--

CREATE TABLE IF NOT EXISTS `materiel_experience` (
  `labelMateriel` varchar(200) NOT NULL,
  `labelExperience` varchar(200) NOT NULL,
  KEY `fk_exp` (`labelExperience`),
  KEY `fk_mat` (`labelMateriel`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `variable`
--

CREATE TABLE IF NOT EXISTS `variable` (
  `labelVariable` varchar(200) NOT NULL,
  PRIMARY KEY (`labelVariable`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `variable_experience`
--

CREATE TABLE IF NOT EXISTS `variable_experience` (
  `labelVariable` varchar(200) NOT NULL,
  `labelExperience` varchar(20) NOT NULL,
  `valeur` varchar(3000) NOT NULL,
  `numero` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
