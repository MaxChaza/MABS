/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.util;

import biobook.view.ExpPersoView;
import java.awt.event.KeyEvent;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.JTextComponent;

/**
 *
 * @author Maxime
 */
public class MaxCaracteres {
    public MaxCaracteres(){}
    
    public static void controler(KeyEvent e, JTextComponent component, int nbCar){
        if(e.getSource().equals(component)){
                if(component.getText().length()>nbCar) {
                    JOptionPane.showMessageDialog(null, "Vous avez atteint le nombre de caractères maximum.", "Attention", JOptionPane.WARNING_MESSAGE);

                    try {
                        component.setText(component.getText(0, nbCar));
                    } catch (BadLocationException ex) {
                        Logger.getLogger(ExpPersoView.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

            }
    }
}
