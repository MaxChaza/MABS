/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.util;

import biobook.model.Variable;
import biobook.model.VariableExperience;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Maxime
 */
public class GenererCSV {
    public static void writeCSV(HashSet<VariableExperience> listVariable, File path){
        
            BufferedWriter file = null;
            try {
                file = new BufferedWriter(new FileWriter(path+".csv"));
            } catch (IOException ex) {
                Logger.getLogger(GenererCSV.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            Map map = new HashMap();
            for(VariableExperience v : listVariable)
            {
                map.put(v.getNomVariable().getNom(), v);
            }
            Set setOfKeys = map.keySet();
            
            Iterator iteratorKeys = setOfKeys.iterator();
            
            Map listKeys = new HashMap();
            int keyIndice=0;
            while (iteratorKeys.hasNext()) {
                String valKey = (String) iteratorKeys.next();
                listKeys.put(keyIndice, valKey);
                keyIndice++;
            }
            
            // Premiere ligne des nom de ValeurExperience
            Set setOfKeysIndice = listKeys.keySet();
            Iterator iteratorKeysIndice = setOfKeysIndice.iterator();
            List<VariableExperience> listVariableExperience = null;
            
            while (iteratorKeysIndice.hasNext()) {
                int ind = (int) iteratorKeysIndice.next();
                String value =  (String) listKeys.get(ind);
                StringBuffer stPointVirgule = new StringBuffer();
                
                stPointVirgule.append(value);
                
                // On créé une liste de valeur triée
                
                listVariableExperience = null;
                listVariableExperience = new ArrayList<VariableExperience>();
                
                for(VariableExperience v : listVariable){
                    if(v.getNomVariable().getNom().equals(value)){
                        listVariableExperience.add(v);
                    }
                }
                Collections.sort(listVariableExperience);
                
                for(VariableExperience uneVar : listVariableExperience)
                {
                    stPointVirgule.append(";");
                    stPointVirgule.append(uneVar.getValeur());
                }
                stPointVirgule.append("\n");
                try {
                    file.write(stPointVirgule.toString());
                } catch (IOException ex) {
                    Logger.getLogger(GenererCSV.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
                        
            try {
                file.close();
            } catch (IOException ex) {
                Logger.getLogger(GenererCSV.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
}

