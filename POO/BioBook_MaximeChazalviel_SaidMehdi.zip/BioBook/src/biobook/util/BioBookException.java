package biobook.util;

public class BioBookException  extends Exception{
	
		private   final long serialVersionUID = 1L;

		public BioBookException(){
			super();
		}
		
		public BioBookException(String msg){
			super(msg);
		}

	}

