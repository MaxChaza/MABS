/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.view;

import biobook.model.Variable;
import biobook.model.VariableExperience;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.event.TableModelEvent;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Maxime
 */
public class JTableModelVariable extends AbstractTableModel {

    private HashSet<VariableExperience> listeVariable;
    private HashSet<Variable> listeNomVariable;
    private Object data[][];
    private int nbCol;
    private int nbRaw;
    public JTableModelVariable(HashSet<VariableExperience> liste){
        
        listeVariable=liste;
        nbCol = 1;
        for (VariableExperience v : listeVariable) {
            int i=0;
            for (VariableExperience v2 : listeVariable) {
                if (v.getNomVariable().getNom().equals(v2.getNomVariable().getNom())) {
                    i++;
                    if(i>nbCol) {
                        nbCol=i;
                    }
                }
            }
        }
        nbCol++;
        listeNomVariable = new HashSet<>();
        Map map = new HashMap();
            for (VariableExperience v : listeVariable) {
            map.put(v.getNomVariable().getNom(), v);
        }
        Set setOfKeys = map.keySet();

        Iterator iteratorKeys = setOfKeys.iterator();

        Map listKeys = new HashMap();
        int keyIndice = 0;
        while (iteratorKeys.hasNext()) {
            String valKey = (String) iteratorKeys.next();
            listKeys.put(keyIndice, valKey);
            keyIndice++;
        }
        nbRaw = keyIndice;
        
        data = new Object[nbRaw+1][getColumnCount() + 2];
           
        // Premiere ligne des nom de ValeurExperience
        Set setOfKeysIndice = listKeys.keySet();
        Iterator iteratorKeysIndice = setOfKeysIndice.iterator();
        List<VariableExperience> listVariableExperience = null;
        
        while (iteratorKeysIndice.hasNext()) {
            
            int ind = (int) iteratorKeysIndice.next();
            
            String value = (String) listKeys.get(ind);
            listeNomVariable.add(new Variable(value));
            // On créé une liste de valeur triée

            listVariableExperience = null;
            listVariableExperience = new ArrayList<VariableExperience>();

            for (VariableExperience v : listeVariable) {
                if (v.getNomVariable().getNom().equals(value)) {
                    listVariableExperience.add(v);
                }
            }
//          data[row][col] 
            data[ind][0] = value;
            
            Collections.sort(listVariableExperience);
            int i = 1;
            for (VariableExperience uneVar : listVariableExperience) {
                data[ind][i] = uneVar.getValeur();
                if(i>nbCol) {
                    nbCol=i;
                }
                i++;
            }
        }
    }
  
    public HashSet<VariableExperience> getListeVariable() {
        return listeVariable;
    }

    public void setListeVariable(HashSet<VariableExperience> listeVariable) {
        this.listeVariable = listeVariable;
    }

    public Object[][] getData() {
        return data;
    }

    public void setValueAt(Object value, int row, int col) {
            data[row][col] = value;
            fireTableCellUpdated(row, col);
    }
    
    public void setData(Object[][] data) {
        this.data = data;
    }

    public int getNbCol() {
        return nbCol;
    }

    public void setNbCol(int nbCol) {
        
        this.nbCol = nbCol;
    }
    
    public int getColumnCount() {
        
        
        return nbCol;
    }

    public int getRowCount() {            
        return nbRaw;
    }
    
    public void addColumn() {
        Object newBuffer[][]= new Object[nbRaw][nbCol];
        for (int i = 0; i < nbRaw; i++) {
            for (int j = 0; j < nbCol; j++) {
                newBuffer[i][j] = data[i][j];
            }        
        }
        nbCol++;
        data= new Object[nbRaw][nbCol];
        
        for (int i = 0; i < nbRaw; i++) {
            for (int j = 0; j < nbCol-1; j++) {
                data[i][j] = newBuffer[i][j];
            }        
        }
    }

    public void addRow() {
        Object newBuffer[][]= new Object[nbRaw][nbCol];
        for (int i = 0; i < nbRaw; i++) {
            for (int j = 0; j < nbCol; j++) {
                newBuffer[i][j] = data[i][j];
            }        
        }
        nbRaw++;
        data= new Object[nbRaw][nbCol];
        
        for (int i = 0; i < nbRaw-1; i++) {
            for (int j = 0; j < nbCol; j++) {
                data[i][j] = newBuffer[i][j];
            }        
        }
    }
    public Object getValueAt(int row, int col) {
            return data[row][col];
    }
}
