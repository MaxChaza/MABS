package biobook.model;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Objects;
/**
 *
 * @author Said
 */
public class Variable implements Serializable, Comparable {
      private final long serialVersionUID = 6L;
    private String nom;
    public Variable(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
    

    @Override
    public String toString() {
        StringBuffer s = new StringBuffer();;
        s.append(nom);
        
        return s.toString();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Variable other = (Variable) obj;
        return Objects.equals(this.nom, other.nom);
    }
    
    @Override
    public int compareTo(Object o) {
        return this.nom.compareTo(((Variable) o).nom);
    }
}

