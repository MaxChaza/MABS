package biobook.model;
import java.io.Serializable;
import java.sql.Date;
import java.util.HashSet;
import java.util.Objects;
/**
 *
 * @author Said
 */
public class VariableExperience implements Serializable, Comparable {
      private final long serialVersionUID = 6L;
    private Variable nomVariable;
    private String valeur;
    private int numero;
    private String nomExperience;
    
    public VariableExperience(Variable maVariable, String val, int num, String nomExp) {
        nomVariable=maVariable;
        valeur=val;
        numero =num;
        nomExperience=nomExp;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getValeur() {
        return valeur;
    }

    public void setValeur(String valeur) {
        this.valeur = valeur;
    }

   
    public Variable getNomVariable() {
        return nomVariable;
    }

    public void setNomVariable(Variable nomVariable) {
        this.nomVariable = nomVariable;
    }

    public String getNomExperience() {
        return nomExperience;
    }

    public void setNomExperience(String nomExperience) {
        this.nomExperience = nomExperience;
    }

    @Override
    public String toString() {
        StringBuffer s = new StringBuffer();;
        s.append(nomVariable);
        s.append(" ");
        s.append(valeur);
        
        return s.toString();
    }
    
    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final VariableExperience other = (VariableExperience) obj;
        return (Objects.equals(this.nomVariable, other.nomVariable) && Objects.equals(this.nomExperience, other.nomExperience)&& Objects.equals(this.numero, other.numero));
    }
    
    @Override
    public int compareTo(Object o) {
        Integer iThis = this.numero;
        Integer iO = ((VariableExperience) o).numero;
        return iThis.compareTo(iO);
    }
}

