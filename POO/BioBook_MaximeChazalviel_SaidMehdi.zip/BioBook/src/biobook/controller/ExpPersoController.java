/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.controller;

import biobook.model.Chercheur;
import biobook.model.Doc;
import biobook.model.DocumentJoint;
import biobook.model.Experience;
import biobook.model.Materiel;
import biobook.model.Variable;
import biobook.model.VariableExperience;
import biobook.util.BioBookException;
import biobook.util.GenererCSV;
import biobook.util.GererFile;
import biobook.view.ExpPersoView;
import biobook.view.JTableModelVariable;
import java.awt.Color;
import java.awt.FlowLayout;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.Date;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import javax.swing.AbstractListModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListModel;
import javax.swing.UIManager;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
import javax.swing.text.Document;

/**
 *
 * @author Maxime
 */
public class ExpPersoController {

    private ExpPersoView expPersoView;
    private GererExperience gererExperience;
    private GererMateriel gererMateriel;
    private GererChercheur gererChercheur;
    private boolean isCreateur;
    private Experience expChoisie;
    private GererVariable gererVariable;
    private GererDocument gererDocument;
    private GererVariableExperience gererVariableExperience;
    private GererMaterielExperience gererMaterielExperience;
    private GererChercheurExperience gererChercheurExperience;
//    private JTable jTableVariable;
    private int nbMatJComboBox;

    public int getNbMatJComboBox() {
        return nbMatJComboBox;
    }

    public void setNbMatJComboBox(int nbMatJComboBox) {
        this.nbMatJComboBox = nbMatJComboBox;
    }

    public ExpPersoController(ExpPersoView aThis) {
        expPersoView = aThis;
        gererChercheurExperience = new GererChercheurExperience();
        gererExperience = new GererExperience();
        gererMateriel = new GererMateriel();
        gererChercheur = new GererChercheur();
        gererVariable = new GererVariable();
        gererVariableExperience = new GererVariableExperience();
        gererMaterielExperience = new GererMaterielExperience();
        gererDocument = new GererDocument();

    }

    public void chooseExp(boolean isC) throws BioBookException, IOException, IOException, FileNotFoundException, ClassNotFoundException, SQLException {
        clickAnnulerAssumption();
        clickAnnulerLibelle();
        clickAnnulerProblem();
        clickAnnulerStateOfTheArt();
        clickAnnulerParticipants();
        clickAnnulerMateriels();

        clickAnnulerMethode();
        expPersoView.getSupprimerExperience().setVisible(false);

        isCreateur = isC;
        expPersoView.getLabelSansExp().setVisible(false);

        expPersoView.getModifierLibelle().setVisible(false);
        expChoisie = null;
        if (isCreateur) {
            expChoisie = (Experience) expPersoView.getJlistCree().getSelectedValue();
            expPersoView.getModifierLibelle().setVisible(true);
            expPersoView.getModifierParticipants().setVisible(true);
            expPersoView.getDualBoxParticipants().getSourceList().setEnabled(true);
            expPersoView.getSupprimerExperience().setVisible(true);
        } else {
            expPersoView.getDualBoxParticipants().getSourceList().setSelectedIndices(new int[]{});
            expPersoView.getDualBoxParticipants().getSourceList().setEnabled(false);

            expPersoView.getModifierParticipants().setVisible(false);
            expChoisie = (Experience) expPersoView.getJlistParticipe().getSelectedValue();
        }
        expPersoView.getTabbedExperiencesPersoDroite().setVisible(true);
        expPersoView.getModifierProblem().setVisible(true);
        expPersoView.getModifierAssumption().setVisible(true);
        expPersoView.getModifierMethode().setVisible(true);
        expPersoView.getModifierStateOfTheArt().setVisible(true);

        expPersoView.getjLabelTitreLibelle().setVisible(true);
        expPersoView.getjLabelLibelle().setVisible(true);
        expPersoView.getjLabelLibelle().setText(expChoisie.getLabel());
        expPersoView.getjTextLibelle().setText(expChoisie.getLabel());

        expPersoView.getjLabelTitreAssumption().setVisible(true);
        expPersoView.getjLabelAssumption().setVisible(true);
        expPersoView.getjLabelAssumption().setText(expChoisie.getAssumption());
        expPersoView.getjTextAssumption().setText(expChoisie.getAssumption());

        expPersoView.getjLabelTitreMethode().setVisible(true);
        expPersoView.getjLabelMethode().setVisible(true);
        expPersoView.getjLabelMethode().setText(expChoisie.getMethode());
        expPersoView.getjTextMethode().setText(expChoisie.getMethode());

        expPersoView.getjLabelTitreStateOfTheArt().setVisible(true);
        expPersoView.getjLabelStateOfTheArt().setVisible(true);
        expPersoView.getjLabelStateOfTheArt().setText(expChoisie.getStateOfTheArt());
        expPersoView.getjTextStateOfTheArt().setText(expChoisie.getStateOfTheArt());

        expPersoView.getProblem().setVisible(true);
        expPersoView.getTitreProblem().setVisible(true);
        expPersoView.getProblem().setText(expChoisie.getProblem());
        expPersoView.getjTextProblem().setText(expChoisie.getProblem());

        expPersoView.getjLabelCreateur().setVisible(true);
        expPersoView.getjLabelCreateur().setText(expChoisie.getCreateur().getFirstName() + " " + expChoisie.getCreateur().getUserName());
        expPersoView.getjLabelTitreCreateur().setVisible(true);



//      Récupération des chercheurs  
        Object[] listParticipants = expChoisie.getListChercheur().toArray();
//        }

        expPersoView.getDualBoxParticipants().clearSourceListModel();
        expPersoView.getDualBoxParticipants().addFirstSourceElements(listParticipants);

        HashSet<Chercheur> tous = new HashSet();
        boolean participe = false;
        // Récupération des chercheur qui ne sont pas dans cette exp
        for (Chercheur chercheurBuff : gererChercheur.getChercheurs()) {
            if (!chercheurBuff.equals(expPersoView.getEspacePersoView().getMain().getChercheurConnecte())) {
                participe = false;
                for (Chercheur chercheurParticipe : expChoisie.getListChercheur()) {
                    if (chercheurParticipe.equals(chercheurBuff)) {
                        participe = true;
                    }
                }
                if (!participe) {
                    // Nom du chercheur
                    tous.add(chercheurBuff);
                }
            }
        }
        tous.remove(new Chercheur(expPersoView.getEspacePersoView().getMain().getChercheurConnecte()));
        Object[] listToutLesChercheurs = tous.toArray();
        


        // Recuperation des materiels
        expPersoView.getDualBoxMateriels().clearSourceListModel();
        expPersoView.getDualBoxParticipants().addFirstDestinationElements(listToutLesChercheurs);
        expPersoView.getDualBoxParticipants().setVisible(true);
        // Récupération des materiels
        Object[] listMateriels = expChoisie.getListMateriels().toArray();

        expPersoView.getDualBoxMateriels().addFirstSourceElements(listMateriels);
        nbMatJComboBox = 0;
        HashSet tousMat = new HashSet();
        boolean materielDeLExperience = false;
        // Récupération des Materiel qui ne sont pas dans cette exp
        for (Materiel materielBuff : gererMateriel.getMateriels()) {
            for (Materiel materielParticipe : expChoisie.getListMateriels()) {
                if (materielParticipe.equals(materielBuff)) {
                    materielDeLExperience = true;
                }
            }
            if (!materielDeLExperience) {
                // Nom du materiel
                nbMatJComboBox++;
                tousMat.add(materielBuff);
            }
        }

        Object[] listToutLesMateriels = tousMat.toArray();

        expPersoView.getjComboBoxMateriels().setEditable(true);
        DefaultComboBoxModel def = new DefaultComboBoxModel(listToutLesMateriels);
        expPersoView.getjComboBoxMateriels().setModel(def);

        expPersoView.getDualBoxMateriels().setVisible(true);



        // Récupération des Variables
        expPersoView.getPanelBouttonVariable().setVisible(true);

        expPersoView.getPanelJtextVar().setVisible(true);
        expPersoView.getExportVariable().setVisible(true);

        expPersoView.jTableVariable.setModel(new JTableModelVariable(expChoisie.getListVariables()));

        HashSet tousVar = new HashSet();
        boolean variableDeLExperience = false;
        // Récupération des Variable qui ne sont pas dans cette exp
        HashSet<VariableExperience> listVarExp = gererVariableExperience.getAllByExp(expChoisie.getLabel());
        for (VariableExperience variableBuff : listVarExp) {
            for (VariableExperience variable : expChoisie.getListVariables()) {
                if (variable.equals(variableBuff)) {
                    variableDeLExperience = true;
                }
            }
            if (!variableDeLExperience) {
                // Nom du materiel
                tousMat.add(variableBuff);
            }
        }

        Object[] listToutLesVariables = tousMat.toArray();

        // Récupération des Documents

        expPersoView.getPanelBouttonDocument().setVisible(true);
        
        Object[] listDocs = expChoisie.getListDocuments().toArray();
        expPersoView.getDualBoxDocuments().clearSourceListModel();
        expPersoView.getDualBoxDocuments().addFirstSourceElements(listDocs);


        HashSet tousDoc = new HashSet();
        boolean documentDeLExperience = false;
        // Récupération des Doc qui ne sont pas dans cette exp
        HashSet<Doc> listDocExp = gererDocument.getAllByExp(expChoisie.getLabel());
        for (Doc documentBuff : listDocExp) {
            for (Doc document : expChoisie.getListDocuments()) {
                if (document.equals(documentBuff)) {
                    documentDeLExperience = true;
                }
            }
            if (!documentDeLExperience) {
                // Nom du materiel
                tousMat.add(documentBuff);
            }
        }
        Object[] listToutLesDocs = tousMat.toArray();

    }

    public void clickModifierLibelle() {
        expPersoView.getjTextLibelle().setVisible(true);
        expPersoView.getValiderLibelle().setVisible(true);
        expPersoView.getAnnulerLibelle().setVisible(true);

        expPersoView.getjLabelLibelle().setVisible(false);
        expPersoView.getModifierLibelle().setVisible(false);

        clickAnnulerAssumption();
        clickAnnulerMethode();
        clickAnnulerStateOfTheArt();
        clickAnnulerProblem();
    }

    public void clickModifierProblem() {
        expPersoView.getjTextProblem().setVisible(true);
        expPersoView.getValiderProblem().setVisible(true);
        expPersoView.getAnnulerProblem().setVisible(true);

        expPersoView.getProblem().setVisible(false);
        expPersoView.getModifierProblem().setVisible(false);


        clickAnnulerAssumption();
        clickAnnulerMethode();
        clickAnnulerStateOfTheArt();
        clickAnnulerLibelle();
    }

    public void clickModifierAssumption() {
        expPersoView.getjTextAssumption().setVisible(true);
        expPersoView.getValiderAssumption().setVisible(true);
        expPersoView.getAnnulerAssumption().setVisible(true);

        expPersoView.getjLabelAssumption().setVisible(false);
        expPersoView.getModifierAssumption().setVisible(false);

        clickAnnulerLibelle();
        clickAnnulerMethode();
        clickAnnulerStateOfTheArt();
        clickAnnulerProblem();
    }

    public void clickModifierStateOfTheArt() {
        expPersoView.getjTextStateOfTheArt().setVisible(true);
        expPersoView.getValiderStateOfTheArt().setVisible(true);
        expPersoView.getAnnulerStateOfTheArt().setVisible(true);

        expPersoView.getjLabelStateOfTheArt().setVisible(false);
        expPersoView.getModifierStateOfTheArt().setVisible(false);

        clickAnnulerAssumption();
        clickAnnulerMethode();
        clickAnnulerLibelle();
        clickAnnulerProblem();
    }

    public void clickModifierMethode() {
        expPersoView.getjTextMethode().setVisible(true);
        expPersoView.getValiderMethode().setVisible(true);
        expPersoView.getAnnulerMethode().setVisible(true);
        expPersoView.getjScrollPaneTextMethode().setVisible(true);

        expPersoView.getjScrollPaneLabelMethode().setVisible(false);
        expPersoView.getjLabelMethode().setVisible(false);
        expPersoView.getModifierMethode().setVisible(false);

        clickAnnulerAssumption();
        clickAnnulerLibelle();
        clickAnnulerStateOfTheArt();
        clickAnnulerProblem();
    }

    public void clickAnnulerLibelle() {
        expPersoView.getjTextLibelle().setVisible(false);
        expPersoView.getValiderLibelle().setVisible(false);
        expPersoView.getAnnulerLibelle().setVisible(false);

        expPersoView.getjLabelLibelle().setVisible(true);
        expPersoView.getModifierLibelle().setVisible(true);
    }

    public void clickAnnulerProblem() {
        expPersoView.getjTextProblem().setVisible(false);
        expPersoView.getValiderProblem().setVisible(false);
        expPersoView.getAnnulerProblem().setVisible(false);

        expPersoView.getProblem().setVisible(true);
        expPersoView.getModifierProblem().setVisible(true);
    }

    public void clickAnnulerAssumption() {
        expPersoView.getjTextAssumption().setVisible(false);
        expPersoView.getValiderAssumption().setVisible(false);
        expPersoView.getAnnulerAssumption().setVisible(false);

        expPersoView.getjLabelAssumption().setVisible(true);
        expPersoView.getModifierAssumption().setVisible(true);
    }

    public void clickAnnulerStateOfTheArt() {
        expPersoView.getjTextStateOfTheArt().setVisible(false);
        expPersoView.getValiderStateOfTheArt().setVisible(false);
        expPersoView.getAnnulerStateOfTheArt().setVisible(false);

        expPersoView.getjLabelStateOfTheArt().setVisible(true);
        expPersoView.getModifierStateOfTheArt().setVisible(true);
    }

    public void clickAnnulerMethode() {
        expPersoView.getjTextMethode().setVisible(false);
        expPersoView.getValiderMethode().setVisible(false);
        expPersoView.getAnnulerMethode().setVisible(false);
        expPersoView.getjScrollPaneTextMethode().setVisible(false);

        expPersoView.getjScrollPaneLabelMethode().setVisible(true);
        expPersoView.getjLabelMethode().setVisible(true);
        expPersoView.getModifierMethode().setVisible(true);
    }

    public void clickModifierParticipants() {
        expPersoView.getModifierParticipants().setVisible(false);
        expPersoView.getValiderParticipants().setVisible(true);
        expPersoView.getAnnulerParticipants().setVisible(true);
        expPersoView.getDualBoxParticipants().clickModif();
    }

    public void clickAnnulerParticipants() {
        expPersoView.getModifierParticipants().setVisible(true);
        expPersoView.getValiderParticipants().setVisible(false);
        expPersoView.getAnnulerParticipants().setVisible(false);
        expPersoView.getDualBoxParticipants().clickAnnuler();
    }

    public void clickAnnulerMateriels() {
        expPersoView.getModifierMateriels().setVisible(true);

        expPersoView.getPanelBouttonMateriel().setVisible(false);
        expPersoView.getjComboBoxMateriels().setVisible(false);
        expPersoView.getValiderMateriels().setVisible(false);
        expPersoView.getAnnulerMateriels().setVisible(false);

//        expPersoView.getDualBoxMateriels().clickAnnuler();
    }

    public void clickModifierMateriels() {
        expPersoView.getModifierMateriels().setVisible(false);

        expPersoView.getPanelBouttonMateriel().setVisible(true);
        expPersoView.getjComboBoxMateriels().setVisible(true);
        expPersoView.getValiderMateriels().setVisible(true);
        expPersoView.getAnnulerMateriels().setVisible(true);

    }

    public void clickValiderMateriels() throws BioBookException, BioBookException, IOException, FileNotFoundException, FileNotFoundException, ClassNotFoundException, ClassNotFoundException, SQLException {
        clickAnnulerMateriels();

    }

    public void clickAddMateriel() throws SQLException, BioBookException, NoSuchAlgorithmException {
        if (expPersoView.getjComboBoxMateriels().getSelectedItem() != null) {
            Object o[] = new Object[1];
            Materiel m = null;
            if (!expChoisie.getListVariables().contains(o)) {
                if (expPersoView.getjComboBoxMateriels().getSelectedItem().getClass().equals("".getClass())) {
                    m = new Materiel((String) expPersoView.getjComboBoxMateriels().getSelectedItem());

                    if (!gererMateriel.exist(expPersoView.getjComboBoxMateriels().getSelectedItem().toString()));
                    {
                        gererMateriel.insertMateriel(m);
                    }
                    o[0] = m;
                    gererMaterielExperience.insertMaterielExperience(m.getName(), expChoisie.getLabel());
                } else {
                    m = (Materiel) expPersoView.getjComboBoxMateriels().getSelectedItem();
                    o[0] = m;
                    gererMaterielExperience.insertMaterielExperience(m.getName(), expChoisie.getLabel());
                }
            }

            expPersoView.getDualBoxMateriels().addSourceElements(o);
            expPersoView.getjComboBoxMateriels().removeItem(expPersoView.getjComboBoxMateriels().getSelectedItem());
        } else {
            JOptionPane.showMessageDialog(expPersoView, "Veuillez saisir un materiel pour le créer.", "Attention", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clickSuppMateriel() throws SQLException, BioBookException, NoSuchAlgorithmException {
        if (!expPersoView.getDualBoxMateriels().getSourceList().isSelectionEmpty()) {
            Object o[] = new Object[1];
            Materiel m = (Materiel) expPersoView.getDualBoxMateriels().getSourceList().getSelectedValue();
            o[0] = expPersoView.getjComboBoxMateriels().getSelectedItem();
            expPersoView.getjComboBoxMateriels().addItem(expPersoView.getDualBoxMateriels().getSourceList().getSelectedValue());
            expPersoView.getDualBoxMateriels().clearSourceSelected();
            gererMaterielExperience.deleteMaterielExperience(m.getName(), expChoisie.getLabel());
        }
    }

    public void clickAddDocument() throws FileNotFoundException, IOException, BioBookException {

        String pathToFile = "./src/biobook/file/";
        JFileChooser choose = new JFileChooser();
        choose.showDialog(choose, "Importer");

        File f = new File(".");
        File fileSource = choose.getSelectedFile();
        File fileDest = new File(pathToFile + fileSource.getName());

        gererDocument.insert(new Doc(fileSource.getName(), f.getPath() + "/src/biobook/file/", expChoisie.getLabel()));

        GererFile.copyFile(fileSource, fileDest);
        Doc document = new Doc(fileSource.getName(), fileDest.getPath(), expChoisie.getLabel()) {
        };

        Object o[] = new Object[1];
        o[0] = document;

        expPersoView.getDualBoxDocuments().addSourceElements(o);
    }

    public void clickSuppDocument() throws BioBookException {
        File myFile = new File("./src/biobook/file/" + expPersoView.getDualBoxDocuments().getSourceList().getSelectedValue());
        myFile.delete();
        gererDocument.delete(new Doc(myFile.getName(), "", expChoisie.getLabel()));
        expPersoView.getDualBoxDocuments().clearSourceSelected();
    }

    public void clickSuppExperience() throws BioBookException, SQLException {
        int choix = JOptionPane.showConfirmDialog(expPersoView, "Voulez vous vraiment supprimer cette expérience?", "Supprimer experience", JOptionPane.WARNING_MESSAGE, JOptionPane.WARNING_MESSAGE);
        if (choix == JOptionPane.YES_OPTION)
        {
//            reset();
            clickAnnulerAssumption();
            clickAnnulerLibelle();
            clickAnnulerProblem();
            clickAnnulerStateOfTheArt();
            clickAnnulerParticipants();
            clickAnnulerMateriels();
            clickAnnulerMethode();
            expPersoView.getSupprimerExperience().setVisible(false);
            expPersoView.getLabelSansExp().setVisible(true);

            expPersoView.getModifierLibelle().setVisible(false);
            expChoisie = null;
            if (isCreateur) {
                expChoisie = (Experience) expPersoView.getJlistCree().getSelectedValue();
                expPersoView.getModifierLibelle().setVisible(false);
                expPersoView.getModifierParticipants().setVisible(false);
                expPersoView.getDualBoxParticipants().getSourceList().setEnabled(false);
                expPersoView.getSupprimerExperience().setVisible(false);
            } else {
                expPersoView.getDualBoxParticipants().getSourceList().setSelectedIndices(new int[]{});
                expPersoView.getDualBoxParticipants().getSourceList().setEnabled(false);

                expPersoView.getModifierParticipants().setVisible(false);
            }
            expPersoView.getTabbedExperiencesPersoDroite().setVisible(false);
            expPersoView.getModifierProblem().setVisible(false);
            expPersoView.getModifierAssumption().setVisible(false);
            expPersoView.getModifierMethode().setVisible(false);
            expPersoView.getModifierStateOfTheArt().setVisible(false);

            expPersoView.getjLabelTitreLibelle().setVisible(false);
            expPersoView.getjLabelLibelle().setVisible(false);

            expPersoView.getjLabelTitreAssumption().setVisible(false);
            expPersoView.getjLabelAssumption().setVisible(false);

            expPersoView.getjLabelTitreMethode().setVisible(false);
            expPersoView.getjLabelMethode().setVisible(false);

            expPersoView.getjLabelTitreStateOfTheArt().setVisible(false);
            expPersoView.getjLabelStateOfTheArt().setVisible(false);

            expPersoView.getProblem().setVisible(false);
            expPersoView.getTitreProblem().setVisible(false);

            expPersoView.getjLabelCreateur().setVisible(false);
            expPersoView.getjLabelTitreCreateur().setVisible(false);

             expPersoView.getDualBoxParticipants().setVisible(false);
            // Récupération des materiels
            expPersoView.getDualBoxMateriels().setVisible(false);



            // Récupération des Variables
            expPersoView.getPanelBouttonVariable().setVisible(false);

            expPersoView.getPanelJtextVar().setVisible(false);
            expPersoView.getExportVariable().setVisible(false);

            expPersoView.getPanelBouttonDocument().setVisible(false);
            
            
            gererExperience.deleteExperience(expChoisie);
            gererChercheurExperience.deleteChercheurExperience(expChoisie.getLabel(), expPersoView.getEspacePersoView().getMain().getChercheurConnecte().getLogin());
            gererVariableExperience.deleteAllByExp(expChoisie.getLabel());
            gererMaterielExperience.deleteAllMaterielByExperience(expChoisie);
            gererDocument.deleteAllByExp(expChoisie.getLabel());
            
            List<Experience> newListCree = new ArrayList<>();
            if(!newListCree.isEmpty())
            {

                for (Experience e : newListCree) {
                    newListCree.add(e);
                }
                Collections.sort(newListCree);
            }
            newListCree.remove(expChoisie);
            expPersoView.getJlistCree().removeListSelectionListener(expPersoView);
            expPersoView.getJlistCree().setListData(newListCree.toArray());
            expPersoView.getJlistCree().removeListSelectionListener(expPersoView);
        }
    }

    public void clickValiderLibelle() throws SQLException, BioBookException, IOException, FileNotFoundException, ClassNotFoundException {
        if (expPersoView.getjTextLibelle().isVisible() && !(expPersoView.getjTextLibelle().equals(""))) {
            if (!gererExperience.libelleExist(expPersoView.getjTextLibelle().getText())) {
                expChoisie.setLabel(expPersoView.getjTextLibelle().getText());
                gererExperience.updateExperience(expChoisie);
                clickAnnulerLibelle();
                expPersoView.getjLabelLibelle().setText(expChoisie.getLabel());
                expPersoView.getjTextLibelle().setBackground(Color.WHITE);
                HashSet<Experience> list = expPersoView.getEspacePersoView().getMain().getChercheurConnecte().getListExperiences();
                List<Experience> newList = new ArrayList<>();
                for (Experience e : list) {
                    newList.add(e);
                }
                Collections.sort(newList);
                DefaultListModel modele = new DefaultListModel();
                for (Experience e : newList) {
                    modele.addElement(e);
                }
                expPersoView.getJlistCree().removeListSelectionListener(expPersoView);
                expPersoView.getJlistCree().setModel(modele);
                expPersoView.getJlistCree().addListSelectionListener(expPersoView);
                expPersoView.getJlistCree().setSelectedValue(expChoisie, true);

                expPersoView.getPanelGauche().repaint();
            } else {
                JOptionPane.showMessageDialog(expPersoView, "Ce nom d'expérience est déjà utilisé.", "Attention", JOptionPane.WARNING_MESSAGE);
            }
        } else {

            expPersoView.getjTextLibelle().setBackground(new Color(255, 230,230));
            JOptionPane.showMessageDialog(expPersoView, "Veuillez remplir le champ à modifier.", "Attention", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clickValiderAssumption() throws SQLException, BioBookException {
        if (expPersoView.getjTextAssumption().isVisible() && !(expPersoView.getjTextAssumption().equals(""))) {
            expChoisie.setAssumption(expPersoView.getjTextAssumption().getText());
            gererExperience.updateExperience(expChoisie);
            clickAnnulerAssumption();
            expPersoView.getjLabelAssumption().setText(expChoisie.getAssumption());
            expPersoView.getjTextAssumption().setBackground(Color.WHITE);
        } else {

            expPersoView.getjTextAssumption().setBackground(new Color(255, 230,230));
            JOptionPane.showMessageDialog(expPersoView, "Veuillez remplir le champ à modifier.", "Attention", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clickValiderProblem() throws SQLException, SQLException, BioBookException {
        if (expPersoView.getjTextProblem().isVisible() && !(expPersoView.getjTextProblem().equals(""))) {
            expChoisie.setProblem(expPersoView.getjTextProblem().getText());
            gererExperience.updateExperience(expChoisie);
            clickAnnulerProblem();
            expPersoView.getProblem().setText(expChoisie.getProblem());
            expPersoView.getjTextProblem().setBackground(Color.WHITE);
        } else {

            expPersoView.getjTextProblem().setBackground(new Color(255, 230,230));
            JOptionPane.showMessageDialog(expPersoView, "Veuillez remplir le champ à modifier.", "Attention", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clickValiderMethode() throws BioBookException, SQLException {
        if (expPersoView.getjTextMethode().isVisible() && !(expPersoView.getjTextMethode().equals(""))) {
            expChoisie.setMethode(expPersoView.getjTextMethode().getText());
            gererExperience.updateExperience(expChoisie);
            clickAnnulerMethode();
            expPersoView.getjLabelMethode().setText(expChoisie.getMethode());
            expPersoView.getjTextMethode().setBackground(Color.WHITE);
        } else {

            expPersoView.getjTextMethode().setBackground(new Color(255, 230,230));
            JOptionPane.showMessageDialog(expPersoView, "Veuillez remplir le champ à modifier.", "Attention", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clickValiderStateOfTheArt() throws BioBookException, SQLException {
        if (expPersoView.getjTextStateOfTheArt().isVisible() && !(expPersoView.getjTextStateOfTheArt().equals(""))) {
            expChoisie.setStateOfTheArt(expPersoView.getjTextStateOfTheArt().getText());
            gererExperience.updateExperience(expChoisie);
            clickAnnulerStateOfTheArt();
            expPersoView.getjLabelStateOfTheArt().setText(expChoisie.getStateOfTheArt());
            expPersoView.getjTextStateOfTheArt().setBackground(Color.WHITE);
        } else {

            expPersoView.getjTextStateOfTheArt().setBackground(new Color(255, 230,230));
            JOptionPane.showMessageDialog(expPersoView, "Veuillez remplir le champ à modifier.", "Attention", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void clickValiderParticipants() throws BioBookException, SQLException, NoSuchAlgorithmException {
        HashSet<Chercheur> listSourceSortie = new HashSet<>();
        HashSet<Chercheur> listDestSortie = new HashSet<>();
        int i;

        int tailleFinDest = expPersoView.getDualBoxParticipants().getDestList().getModel().getSize();
        for (i = 0; i < tailleFinDest; i++) {
            Chercheur unCh = (Chercheur) expPersoView.getDualBoxParticipants().getDestList().getModel().getElementAt(i);
            listSourceSortie.add(unCh);
        }

        Object debutSource[] = expPersoView.getDualBoxParticipants().getLastAddSource();
        int tailleDebutSource = expPersoView.getDualBoxParticipants().getLastAddSource().length;
        HashSet<Chercheur> hashDebutSource = new HashSet<>();

        for (i = 0; i < tailleDebutSource; i++) {
            hashDebutSource.add((Chercheur) debutSource[i]);
        }

        HashSet<Chercheur> hashFinSource = new HashSet<>();

        int tailleFinSource = expPersoView.getDualBoxParticipants().getSourceList().getModel().getSize();
        for (i = 0; i < tailleFinSource; i++) {
            Chercheur unCh = (Chercheur) expPersoView.getDualBoxParticipants().getSourceList().getModel().getElementAt(i);
            listSourceSortie.add(unCh);
            hashFinSource.add(unCh);
        }

        for (Chercheur c : hashDebutSource) {
            if (hashFinSource.contains(c)) {
                hashFinSource.remove(c);
                listSourceSortie.add(c);
            } else {
                listDestSortie.add(c);
                gererChercheurExperience.deleteChercheurExperience(expChoisie.getLabel(), c.getLogin());
            }
        }

        for (Chercheur c1 : hashFinSource) {
            gererChercheurExperience.insertChercheurExperience(expChoisie.getLabel(), c1.getLogin());
        }
        expPersoView.getModifierParticipants().setVisible(true);
        expPersoView.getValiderParticipants().setVisible(false);
        expPersoView.getAnnulerParticipants().setVisible(false);
        expPersoView.getDualBoxParticipants().validModif();


        expPersoView.getDualBoxParticipants().setLastAddDest(listDestSortie.toArray());
        expPersoView.getDualBoxParticipants().setLastAddSource(listSourceSortie.toArray());

    }

    public void clickExportDocument() throws BioBookException, SQLException {
        JFileChooser choose = new JFileChooser();
        choose.showDialog(choose, "Exporter");
        File fileSource = choose.getSelectedFile();
        HashSet<VariableExperience> listVar = gererVariableExperience.getAllByExp(expChoisie.getLabel());
        GenererCSV.writeCSV(gererVariableExperience.getAllByExp(expChoisie.getLabel()), fileSource);
    }

    public void clickAddVariables() throws BioBookException, SQLException {
        if (!expPersoView.getjTextLabelVariable().getText().equals("") && !expPersoView.getjTextValeurVariable().getText().equals("")) {
            Variable variable = new Variable(expPersoView.getjTextLabelVariable().getText());
            String valeur = expPersoView.getjTextValeurVariable().getText();        
            JTableModelVariable model = (JTableModelVariable) expPersoView.getjTableVariable().getModel();
               
            if(!expChoisie.getListVariables().isEmpty()) {
                int y = 0;
                int max = 0;
                boolean variableExist = false;
                int nbVar = model.getRowCount();
                int i = 0;
                while(!variableExist && i < nbVar) {
                    if (variable.getNom().toString().equals(model.getValueAt(i, 0).toString())) {
                        y=i;
                        variableExist = true;
                        for (VariableExperience v : expChoisie.getListVariables()) {
                            if(v.getNomVariable().getNom().equals(variable.getNom()))
                            {
                                if (v.getNumero() > max) {
                                    max = v.getNumero();
                                }
                            }
                        }
                    }
                    i++;
                }
                if (variableExist) {
                    
                    model.addColumn();
            
                    model.fireTableRowsUpdated(model.getColumnCount()-1,max+1);
                    model.setValueAt(valeur,y , max+1);
                    VariableExperience vaEx = new VariableExperience(variable , valeur, max+1, expChoisie.getLabel());
                    model.getListeVariable().add(vaEx);
                    expChoisie.getListVariables().add(vaEx);
                    gererVariableExperience.insert(vaEx);

                    expPersoView.getjTableVariable().setModel(model);

                } else {
                    if (!gererVariable.exist(variable.getNom())) {
                        gererVariable.insert(variable);
                    }
                    
                    model.addRow();
                    model.fireTableRowsInserted(model.getRowCount()-1, model.getRowCount()-1);
                    model.setValueAt(variable, model.getRowCount()-1, 0);
                    model.setValueAt(valeur, model.getRowCount()-1, 1);
//                    model.fireTableRowsUpdated(model.getColumnCount()-1,0);
                    model.fireTableDataChanged();
                    VariableExperience vaEx = new VariableExperience(variable , valeur, 1, expChoisie.getLabel());
                    model.getListeVariable().add(vaEx);
                    expChoisie.getListVariables().add(vaEx);
                    gererVariableExperience.insert(vaEx);

                    expPersoView.getjTableVariable().setModel(model);
               }
            } else {
                if(!gererVariable.exist(variable.getNom())) {
                    gererVariable.insert(variable);
                } 
                model.addRow();
                model.fireTableRowsInserted(0,0);
                model.fireTableRowsUpdated(0,0);
                model.setValueAt(variable, 0, 0);
                model.setValueAt(valeur, 0, 1);
                VariableExperience vaEx = new VariableExperience(variable , valeur, 1, expChoisie.getLabel());
                model.getListeVariable().add(vaEx);
                expChoisie.getListVariables().add(vaEx);
                gererVariableExperience.insert(vaEx);

                
                expPersoView.getjTableVariable().setModel(model);
            }
        } else {
            JOptionPane.showMessageDialog(expPersoView, "Veulliez saisir la variable et sa valeur", "Attention", JOptionPane.WARNING_MESSAGE);
        }
        
    }
}
