/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.controller;

import biobook.model.DocumentJoint;
import biobook.model.Variable;
import biobook.model.VariableExperience;
import biobook.util.BioBookException;
import biobook.util.SimpleConnection;
import com.mysql.jdbc.Connection;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Maxime
 */
public class GererVariableExperience {
    
    private   final String reqInsert = "INSERT INTO variable_experience (labelVariable, labelExperience, valeur, numero)VALUES(?,?,?,?)";    
    private   final String reqAllByExp= "SELECT * FROM variable_experience where labelExperience=?";
    private   final String reqDeleteAllByExp= "DELETE FROM variable_experience WHERE labelExperience=?"; 
    private   final String reqDelete= "DELETE FROM variable_experience WHERE labelExperience=? and labelVariable=?";
    private   java.sql.Connection c;
    private GererExperience gE;
    
    public GererVariableExperience(){
        
    }
    /** Insert un <code>Variable</code> en base de donnï¿½es.
     * @param docJoint 
     * @throws java.sql.SQLException
     * @throws biobook.util.BioBookException
     * @throws java.security.NoSuchAlgorithmException 
     * @throws java.io.IOException 
     * @throws java.io.FileNotFoundException 
     * @throws java.lang.ClassNotFoundException 
	*/
    public void insert(VariableExperience docJoint) throws BioBookException, SQLException {
        // Appel ÃƒÂ  la classe Simple connection pour accÃƒÂ©der ÃƒÂ  la base de donnÃƒÂ©es
        c = null;
        c = SimpleConnection.getInstance().getConnection();
        PreparedStatement pst = null;
        try
        {
                pst = c.prepareStatement(reqInsert);
                              
                pst.setString(1,docJoint.getNomVariable().getNom());
                pst.setString(2,docJoint.getNomExperience());
                pst.setString(3,docJoint.getValeur());
                pst.setInt(4,docJoint.getNumero());
                
                
                               
                pst.executeUpdate();
          
                c.commit();
        }
        catch(SQLException e)
        {
           throw new BioBookException("Problem in the request reqInsert "+e.getMessage());
        }

        finally
        {
            try {
            if (pst!=null)    {  pst.close();}
               }catch (Exception e){
                e.printStackTrace();
            }
        }
        
            c.close();
    }
    
    public HashSet getAllByExp(String labExp) throws BioBookException, SQLException {
        HashSet listVariables = new HashSet<>();

        c = null;
        c = SimpleConnection.getInstance().getConnection();  
        //preparation of the request
        PreparedStatement pst = null;
        ResultSet rs = null;

        try
        {
            pst = c.prepareStatement(reqAllByExp);
            pst.setString(1,labExp);

            

            //Execution of the request
            rs = pst.executeQuery();
        }
        catch (SQLException e)
        {
                throw new BioBookException("Problem when the request reqAllbyExp execute it:"+e.getMessage());
        }

        try
        {
                //Fill in a list
                while(rs.next())
                {
                        // RÃƒÂ©cupÃƒÂ©ration des donnÃƒÂ©es revoyÃƒÂ©es par la base de donnÃƒÂ©es
                        //dans la liste listChercheurs 
                        GererExperience g = new GererExperience();
                        VariableExperience variable= new VariableExperience(new Variable(rs.getString("labelVariable")),rs.getString("valeur"),rs.getInt("numero"),rs.getString("labelExperience"));
                        listVariables.add(variable);

                }
        }
        catch (SQLException e)
        {
                throw new BioBookException("Problem when the list of Variable was create:"+e.getMessage());
         }

        finally
        {
                try {
                if (rs!=null)   {   rs.close();}
                if (pst!=null)    {  pst.close();}
                   }catch (Exception e){
                    e.printStackTrace();
                }
                
            c.close();
        }
       return listVariables;
    } 
    
    
    public void deleteAllByExp(String labExp)throws BioBookException, SQLException {
        // Appel ÃƒÂ  la classe Simple connection pour accÃƒÂ©der ÃƒÂ  la base de donnÃƒÂ©es
        c = null;
        c = SimpleConnection.getInstance().getConnection();
         PreparedStatement pst = null;

        try
        {
                //Execution of the request
                pst = c.prepareStatement(reqDeleteAllByExp);
                
                // On assigne une valeur Ã  chaque "?" prÃ©sent dans la requÃ¨te 
                // pst.set<Type>(<Indice Du "?">,   <Valeur passÃ©>       );
                pst.setString(1,labExp);
                
                // Execution of the request
                // Ceci est necessaire pour toutes les requÃ¨tes qui modifient la base de donnÃ©es
                pst.executeUpdate();
                c.commit();

        }
        catch(SQLException e)
        {
                throw new BioBookException("Problem in the request reqDeleteAllByExp "+e.getMessage());
        }
        finally
        {
            try {
            if (pst!=null)    {  pst.close();}
               }catch (SQLException e){
            }
            
            c.close();
        }
    }
 
    public void delete(VariableExperience docJoint) throws BioBookException, SQLException{
         // Appel ÃƒÂ  la classe Simple connection pour accÃƒÂ©der ÃƒÂ  la base de donnÃƒÂ©es
        java.sql.Connection c=null;
        c = SimpleConnection.getInstance().getConnection();

        //preparation of the request		
        PreparedStatement pst = null;

        try
        {
                pst = c.prepareStatement(reqDelete);

                // On assigne une valeur ÃƒÂ  chaque "?" prÃƒÂ©sent dans la requÃƒÂ¨te 
                // pst.set<Type>(<Indice Du "?">,   <Valeur passÃƒÂ©>       );
                pst.setString(1,docJoint.getNomExperience());
                pst.setString(2,docJoint.getNomVariable().getNom());
                
                // Execution of the request
                // Ceci est necessaire pour toutes les requÃƒÂ¨tes qui modifient la base de donnÃƒÂ©es
                pst.executeUpdate();
                c.commit();

        }
        catch(SQLException e)
        {
                throw new BioBookException("Problem in the request reqDeleteMaterielExperience "+e.getMessage());
        }

        finally
        {
            try {
            if (pst!=null)    {  pst.close();}
               }catch (Exception e){
                e.printStackTrace();
            }
            c.close();
        }
    }
}
