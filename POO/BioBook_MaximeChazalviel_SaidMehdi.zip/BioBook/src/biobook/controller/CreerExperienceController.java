/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.controller;

import biobook.model.Chercheur;
import biobook.model.Experience;
import biobook.util.BioBookException;
import biobook.view.CreerExperienceView;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Vector;
import javax.swing.DefaultListModel;
import javax.swing.JList;

/**
 *
 * @author Maxime
 */
public class CreerExperienceController {

    private CreerExperienceView creerExperienceView;
    private GererExperience gererExperience;

    public CreerExperienceController(CreerExperienceView aThis) {
        creerExperienceView = aThis;
        gererExperience = new GererExperience();
    }

    public void clickValider() throws SQLException, BioBookException, BioBookException, NoSuchAlgorithmException, IOException, IOException, FileNotFoundException, FileNotFoundException, ClassNotFoundException {
        Experience exp = new Experience(
                creerExperienceView.getLabelExperience().getText(),
                creerExperienceView.getProblem().getText(),
                creerExperienceView.getMethode().getText(),
                creerExperienceView.getStateOfTheArt().getText(),
                creerExperienceView.getAssumption().getText(),
                creerExperienceView.getMain().getChercheurConnecte());

                HashSet<Experience> list = creerExperienceView.getMain().getChercheurConnecte().getListExperiences();
                List<Experience> newList = new ArrayList<>();
                for (Experience e : list) {
                    newList.add(e);
                }
                newList.add(exp);
                Collections.sort(newList);
                DefaultListModel modele = new DefaultListModel();
                for (Experience e : newList) {
                    modele.addElement(e);
                }

                gererExperience.insertExperience(exp);
                //ajout de lst2 dans lst

                creerExperienceView.getMain().getEspacePerso().getPanelExpPerso().getJlistCree().removeListSelectionListener(creerExperienceView.getMain().getEspacePerso().getPanelExpPerso());
                creerExperienceView.getMain().getEspacePerso().getPanelExpPerso().getJlistCree().setModel(modele);
                creerExperienceView.getMain().getEspacePerso().getPanelExpPerso().getJlistCree().addListSelectionListener(creerExperienceView.getMain().getEspacePerso().getPanelExpPerso());
                

        }

    public void clickAnnuler() {
        creerExperienceView.dispose();
    }

    public void clickReset() {
        creerExperienceView.getLabelExperience().setText("");
        creerExperienceView.getMethode().setText("");
        creerExperienceView.getProblem().setText("");
        creerExperienceView.getAssumption().setText("");
        creerExperienceView.getStateOfTheArt().setText("");
    }
}
