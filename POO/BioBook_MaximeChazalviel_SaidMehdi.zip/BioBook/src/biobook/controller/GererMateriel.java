package biobook.controller;

import biobook.model.Chercheur;
import biobook.model.Materiel;
import biobook.util.BioBookException;
import biobook.util.MD5;
import biobook.util.SimpleConnection;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import javax.management.MBeanAttributeInfo;

public class GererMateriel {

    private   final String reqInsertIntoMateriel = "INSERT INTO Materiel (labelMateriel)VALUES(?)";
    private   final String reqFindAllMateriels = "SELECT * FROM Materiel";
    private   final String reqFindMateriel = "SELECT * FROM Materiel WHERE labelMateriel=?";
    private   final String reqDeleteMateriel = "DELETE FROM Materiel WHERE labelMateriel=?";
    private   final String reqDeleteAllMateriels = "DELETE FROM Materiel";
    private   Connection c;

    public GererMateriel() {
    }

    public void insertMateriel(Materiel unMateriel) throws SQLException, BioBookException, NoSuchAlgorithmException {
        // Appel à la classe Simple connection pour accéder à la base de données
        c = null;
        c = SimpleConnection.getInstance().getConnection();
        PreparedStatement pst = null;
        try {
            pst = c.prepareStatement(reqInsertIntoMateriel);

            pst.setString(1, unMateriel.getName());

            pst.executeUpdate();

            c.commit();
        } catch (SQLException e) {
            throw new BioBookException("Problem in the request reqInsertIntoMateriel " + e.getMessage());
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            c.close();
        }
    }

    public Collection<Materiel> getMateriels() throws BioBookException, SQLException {
        // Appel à la classe Simple connection pour accéder à la base de données
        c = null;
        c = SimpleConnection.getInstance().getConnection();
        // Initialisation de la liste retournÃ©e par la fonction 
        Collection<Materiel> listMateriels = new HashSet<>();

        //preparation of the request
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = c.prepareStatement(reqFindAllMateriels);

            //Execution of the request
            rs = pst.executeQuery();
        } catch (SQLException e) {
            throw new BioBookException("Problem when the request reqFindAllMateriels execute it:" + e.getMessage());
        }

        //Fill in a list
        while (rs.next()) {
            // RÃ©cupÃ©ration des donnÃ©es revoyÃ©es par la base de donnÃ©es
            //dans la liste listChercheurs 
            Materiel unMateriel = new Materiel(rs.getString("labelMateriel"));
            listMateriels.add(unMateriel);

        }


        try {
            if (rs != null) {
                rs.close();
            }
            if (pst != null) {
                pst.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        c.close();
        return listMateriels;
    }

    /**
     * Delete the
     * <code>Chercheur</code> by login.
     *
     * @throws PerfException
     */
    public void deleteMateriel(Materiel materiel) throws BioBookException, SQLException {
        // Appel à la classe Simple connection pour accéder à la base de données
        c = null;
        c = SimpleConnection.getInstance().getConnection();
        // Appel Ã  la classe Simple connection pour accÃ©der Ã  la base de donnÃ©es
        Connection c = null;
        c = SimpleConnection.getInstance().getConnection();

        //preparation of the request
        PreparedStatement pst = null;

        try {
            //Execution of the request
            pst = c.prepareStatement(reqDeleteMateriel);

            // On assigne une valeur Ã  chaque "?" prÃ©sent dans la requÃ¨te 
            // pst.set<Type>(<Indice Du "?">,   <Valeur passÃ©>       );
            pst.setString(1, materiel.getName());

            // Execution of the request
            // Ceci est necessaire pour toutes les requÃ¨tes qui modifient la base de donnÃ©es
            pst.executeUpdate();
            c.commit();

        } catch (SQLException e) {
            throw new BioBookException("Problem in the request reqDeleteChercheurByLogin " + e.getMessage());
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            c.close();
        }
    }

    /**
     * Delete all
     * <code>Chercheur</code>
     *
     * @throws PerfException
     */
    public void deleteAllMateriels() throws BioBookException, SQLException {
        // Appel Ã  la classe Simple connection pour accÃ©der Ã  la base de donnÃ©es
        Connection c = null;
        c = SimpleConnection.getInstance().getConnection();

        //preparation of the request		
        PreparedStatement pst = null;

        try {
            pst = c.prepareStatement(reqDeleteAllMateriels);

            // Execution of the request
            // Ceci est necessaire pour toutes les requÃ¨tes qui modifient la base de donnÃ©es
            pst.executeUpdate();
            c.commit();

        } catch (SQLException e) {
            throw new BioBookException("Problem in the request DeleteAllChercheurs " + e.getMessage());
        } finally {
            try {
                if (pst != null) {
                    pst.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            c.close();
        }
    }

    boolean exist(String mat) throws BioBookException, SQLException {
        return getMateriel(mat) != null;
    }

    private Materiel getMateriel(String mat) throws BioBookException, SQLException {
        Materiel unMateriel = null;
        // Appel à la classe Simple connection pour accéder à la base de données
        c = null;
        c = SimpleConnection.getInstance().getConnection();

        //préparation de la requète
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = c.prepareStatement(reqFindMateriel);

            // On assigne une valeur à chaque "?" présent dans la requète 
            // pst.set<Type>(<Indice Du "?">,   <Valeur passé>       );
            pst.setString(1, mat);

            // Execution of the request
            // Nécessaire pour tous les SELECT
            rs = pst.executeQuery();
        } catch (SQLException e) {
            throw new BioBookException("Problem when the request reqFindMateriel execute it:" + e.getMessage());
        }
        try {
            if (rs.next()) {
                unMateriel = new Materiel(rs.getString("labelMateriel"));
            }
        } catch (SQLException e) {
            throw new BioBookException("Problem when the Materiel was get" + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException e) {
            }
            c.close();
        }

        return unMateriel;
    }
}
