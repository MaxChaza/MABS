/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.controller;

import biobook.model.DocumentJoint;
import biobook.model.Materiel;
import biobook.model.Variable;
import biobook.util.BioBookException;
import biobook.util.SimpleConnection;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author Maxime
 */
public class GererVariable{
    private   final String reqInsert = "INSERT INTO variable (labelVariable)VALUES(?)";    
    private   final String reqAllByExp= "SELECT * FROM variable";
    private   final String reqDeleteAllByExp= "DELETE FROM variable"; 
    private   final String reqDelete= "DELETE FROM variable WHERE labelVariable=?";
    private   final String reqFindVariable= "SELECT * FROM variable WHERE labelVariable=?";
    private   Connection c;
    
    public GererVariable(){
       
    }
        /** Insert un <code>Chercheur</code> en base de donnï¿½es.
     * @param docJoint 
     * @throws java.sql.SQLException
     * @throws biobook.util.BioBookException
     * @throws java.security.NoSuchAlgorithmException 
     * @throws java.io.IOException 
     * @throws java.io.FileNotFoundException 
     * @throws java.lang.ClassNotFoundException 
	*/

    public void insert(Variable docJoint) throws BioBookException, SQLException {
         // Appel ÃƒÂ  la classe Simple connection pour accÃƒÂ©der ÃƒÂ  la base de donnÃƒÂ©es
        c = null;
        c = SimpleConnection.getInstance().getConnection();
        PreparedStatement pst = null;
        try
        {
                pst = c.prepareStatement(reqInsert);
                              
                pst.setString(1,docJoint.getNom());
                      
                pst.executeUpdate();
          
                c.commit();
        }
        catch(SQLException e)
        {
           throw new BioBookException("Problem in the request reqInsert "+e.getMessage());
        }

        finally
        {
            try {
            if (pst!=null)    {  pst.close();}
               }catch (Exception e){
                e.printStackTrace();
            }
            
            c.close();
        }
    }
    private Variable getVariable(String mat) throws BioBookException, SQLException {
        Variable unVariable = null;
        // Appel à la classe Simple connection pour accéder à la base de données
        c = null;
        c = SimpleConnection.getInstance().getConnection();

        //préparation de la requète
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            pst = c.prepareStatement(reqFindVariable);

            // On assigne une valeur à chaque "?" présent dans la requète 
            // pst.set<Type>(<Indice Du "?">,   <Valeur passé>       );
            pst.setString(1, mat);

            // Execution of the request
            // Nécessaire pour tous les SELECT
            rs = pst.executeQuery();
        } catch (SQLException e) {
            throw new BioBookException("Problem when the request reqFindVariable execute it:" + e.getMessage());
        }
        try {
            if (rs.next()) {
                unVariable = new Variable(rs.getString("labelVariable"));
            }
        } catch (SQLException e) {
            throw new BioBookException("Problem when the Variable was get" + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (pst != null) {
                    pst.close();
                }
            } catch (SQLException e) {
            }
            c.close();
        }

        return unVariable;
    }

    public void delete(DocumentJoint docJoint) throws BioBookException, SQLException{
         // Appel ÃƒÂ  la classe Simple connection pour accÃƒÂ©der ÃƒÂ  la base de donnÃƒÂ©es
        Connection c=null;
        c = SimpleConnection.getInstance().getConnection();

        //preparation of the request		
        PreparedStatement pst = null;

        try
        {
                pst = c.prepareStatement(reqDelete);

                // On assigne une valeur ÃƒÂ  chaque "?" prÃƒÂ©sent dans la requÃƒÂ¨te 
                // pst.set<Type>(<Indice Du "?">,   <Valeur passÃƒÂ©>       );
                pst.setString(1,docJoint.getNom());
                
                // Execution of the request
                // Ceci est necessaire pour toutes les requÃƒÂ¨tes qui modifient la base de donnÃƒÂ©es
                pst.executeUpdate();
                c.commit();

        }
        catch(SQLException e)
        {
                throw new BioBookException("Problem in the request reqDeleteVariableExperience "+e.getMessage());
        }

        finally
        {
            try {
            if (pst!=null)    {  pst.close();}
               }catch (Exception e){
                e.printStackTrace();
            }
            
            c.close();
        }
    }
   /**
     * Insert un <code>Variable</code> dans un fichier.
     *
     * @param variable
     * @throws java.io.FileNotFoundException
     * @throws java.lang.ClassNotFoundException
     */
    public void serializerVariable(Variable variable) throws FileNotFoundException, IOException, ClassNotFoundException {
        // Recherche si ce chercheur existe
        if(deserializerUnVariable(variable.getNom()) == null)
        {
            // Si il existe on insert le chercheur dans le fichier
            // Ouverture du ficher de serialisation des materiels
            FileOutputStream fichier = new FileOutputStream("./src/biobook/serialisation/variable.ser", true);
            try (ObjectOutputStream oos = new ObjectOutputStream(fichier)) {
                oos.writeObject(variable);
                oos.flush();
                oos.close();
                fichier.close(); 
            }
        }
    }
    
    /**
     * rÃ©cupere les <code>Variable</code> dans un fichier.
     *
     * @return liste de Variable
     * @throws java.io.FileNotFoundException
     * @throws java.lang.ClassNotFoundException
     */
    public HashSet<Variable> deserializerVariables() throws FileNotFoundException, IOException, ClassNotFoundException {
        HashSet<Variable> listVariables = new HashSet<>();
        try {
        // Ouverture du ficher de serialisation des chercheur   
            try (FileInputStream fichier = new FileInputStream("./src/biobook/serialisation/variable.ser")) {
                ObjectInputStream ois = new ObjectInputStream(fichier);
                // Iteration sur chaque objet du fichier
                while(ois != null){
                    Variable variable = (Variable) ois.readObject();
                    listVariables.add(variable);
                    ois = new ObjectInputStream(fichier);                    
                }
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
        }
        return listVariables;
    }
    
    /**
     * rÃ©cupere un <code>Variable</code> dans un fichier.
     *
     * @param nom
     * @return 
     * @throws java.io.FileNotFoundException
     * @throws java.lang.ClassNotFoundException
     */
    public Variable deserializerUnVariable(String nom) throws FileNotFoundException, IOException, ClassNotFoundException {
        Variable aVariable = null;
        HashSet<Variable> listVariables = new HashSet<>();
        try {
        // Ouverture du ficher de serialisation des chercheur   
            try (FileInputStream fichier = new FileInputStream("./src/biobook/serialisation/variable.ser")) {
                ObjectInputStream ois = new ObjectInputStream(fichier);
                // Iteration sur chaque objet du fichier
                while(ois != null){
                    Variable variable = (Variable) ois.readObject();
                    listVariables.add(variable);
                    ois = new ObjectInputStream(fichier);                    
                }
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
        }
        for( Variable v : listVariables ) 
        {
            if(v.getNom().equals(nom))
                return v;
        }
        return aVariable;
    }

    
    public boolean exist(String var) throws BioBookException, SQLException{
        return getVariable(var)!=null;
    }

}
    
   
        

    

