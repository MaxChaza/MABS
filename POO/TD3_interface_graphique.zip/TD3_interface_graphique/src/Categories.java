
public enum Categories 
{
	BD,
	MAGAZINE,
	ROMAN,
	JOURNAL,
	MANUEL,
	THEATRE
	

}
