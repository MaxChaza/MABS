/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package biobook.view;

import javax.swing.JPanel;

/**
 *
 * @author Maxime
 */
public class GeneralView extends JPanel{
    public MainFrame main;
    public GeneralView(MainFrame m)
    {
        main = m;
    }
}
