/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package biobook.view;

import com.seaglasslookandfeel.ui.SeaGlassButtonUI;

/**
 *
 * @author Maxime
 */
public class myButton extends SeaGlassButtonUI {

    public myButton(String valider) {
        String t = valider;
    }

    
    
}
