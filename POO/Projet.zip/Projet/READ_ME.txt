Voil� ce que tu vas commencer � faire pour le projet de Java.

1 - Tu installes netbeans.
2 - Tu importes le projet.
3 - Tu installes EasyPHP.
4 - Tu ex�cutes le script SQL pr�sent dans le fichier BioBook\src\biobook\bd.
5 - Tu m'appelles si tu as un probl�me.

6 - Tu vas enfin pouvoir travailler!!!
7 - Tu vas faire les classes permettant l'acc�s au base de donn�es.
	Dans le dos biobook\controller il y a un fichier appel� gererChercheur, tu va te servir de cette classe 
	comme exemple et faire les classes correspondantes aux classes de la BD : 
																=> gererChercheurExperience
																=> gererExperience
																=> gererMateriel
																=> gererMaterielExperience
	La classe gererChercheur est comment�e pour bien tout t'expliquer.
	Tu n'as presque qu'� remplacer les variables.
8 - Tu m'appelles si tu as un probl�me.
9 - Tu m'appelles si tu as un probl�me.
10 - Tu m'appelles si tu as un probl�me.
