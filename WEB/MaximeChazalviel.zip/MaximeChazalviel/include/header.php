<script language="javascript" type="text/javascript" src="./js/ajaxCode.js"></script>
</head>
<div class="myName">
    <h1><a href="">Home</a></h1>
</div>
