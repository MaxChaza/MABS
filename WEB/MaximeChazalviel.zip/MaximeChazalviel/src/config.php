<?php
    $host="localhost";
    $login="root";
    $passwd="admin";
    $dbname="exam1";
    $table="users"
?>
