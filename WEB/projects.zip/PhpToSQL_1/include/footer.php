<div id="footer">
    <?php
        
//        $url = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
////        echo $url."counter/counterContact.txt";
//        
//        echo $_SERVER['SCRIPT_NAME'];
////        echo calc($url."counter/counter.txt"); 
//        
    ?> visitor. 
</div>