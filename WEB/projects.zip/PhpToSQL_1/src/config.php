<?php
    $host="localhost";
    $login="root";
    $passwd="admin";
    $dbname="masterbio";
    $table="users"
?>
