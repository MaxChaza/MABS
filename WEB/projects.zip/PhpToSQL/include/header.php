<div class="myName">
                        <h1><a  href="./index.php">Home</a></h1>
</div>
<ul class="menu">
    <li><a>TP1</a>
        <ul>
                <li><a href="./services.php">Service</a></li>
                <li><a href="./contact_us.php">Contact</a></li>
        </ul>
    </li>
    <li><a>TP2</a>
        <ul>
                <li><a href="./login.php">Se connecter</a></li>
                <li><a href="./register.php">S'enregistrer</a></li>
        </ul>
    </li>
    <li><a>TP3</a>
        <ul>
                <li><a href="./exAjax.php">AJAX</a></li>
        </ul>
    </li>
</ul>